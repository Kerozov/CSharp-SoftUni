﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    interface IBrowseable
    {
         string Browse(string sites);
    }
}
