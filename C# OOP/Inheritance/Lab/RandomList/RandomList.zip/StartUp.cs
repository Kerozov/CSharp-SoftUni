﻿using System;

namespace CustomRandomList
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var list = new RandomList();
            list.Add("asdf");
            list.Add("1234");
            list.Add("5678");
            list.Add("5465");
            list.Add("0000");
            Console.WriteLine(list.RandomString());
            Console.WriteLine(list.RandomString());
            Console.WriteLine(list.RandomString());
            Console.WriteLine(list.RandomString());
        }
    }
}
