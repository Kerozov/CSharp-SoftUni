﻿using System;

namespace Farm
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
