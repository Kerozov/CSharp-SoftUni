﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    class Dog
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
